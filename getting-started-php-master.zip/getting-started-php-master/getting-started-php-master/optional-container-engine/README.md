# 8 - Deploying to Google Container Engine

This folder contains the sample code for the [Deploying to Google Container Engine][tutorial-gke]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[tutorial-gke]: https://cloud.google.com/php/tutorials/bookshelf-on-container-engine

