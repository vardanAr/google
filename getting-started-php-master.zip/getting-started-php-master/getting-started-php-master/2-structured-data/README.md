# 2 - Structured data

This folder contains the sample code for the [Structured data][step-2]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-2]: https://cloud.google.com/php/getting-started/using-structured-data

