# 5 - Logging app events

This folder contains the sample code for the [Logging app events][step-5]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-5]: https://cloud.google.com/php/getting-started/logging-application-events

